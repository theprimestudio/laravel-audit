@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>Reports Management</h1>
        <p>Export developers/management summaries, raw diagnostic CSV files, or API response datasets.</p>
    </div>
</div>

<div class="card">
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Audit Date</th>
                    <th>Overall Score</th>
                    <th>Issues Found</th>
                    <th>Export Formats</th>
                </tr>
            </thead>
            <tbody>
                @forelse($runs as $run)
                    <tr>
                        <td>{{ $run->completed_at ? $run->completed_at->format('Y-m-d H:i:s') : 'Incomplete' }}</td>
                        <td>
                            <strong style="color: var(--primary);">{{ $run->overall_score ? $run->overall_score . '%' : 'N/A' }}</strong>
                        </td>
                        <td>{{ $run->issues_found }} issues</td>
                        <td>
                            <div style="display: flex; gap: 8px;">
                                <a href="{{ route('audit.reports.export', ['run_id' => $run->id, 'format' => 'json']) }}" class="btn btn-secondary" style="padding: 6px 12px; font-size: 0.75rem;">JSON Format</a>
                                <a href="{{ route('audit.reports.export', ['run_id' => $run->id, 'format' => 'csv']) }}" class="btn btn-secondary" style="padding: 6px 12px; font-size: 0.75rem;">CSV Format</a>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" style="text-align: center; color: var(--text-secondary);">No completed audit reports found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
