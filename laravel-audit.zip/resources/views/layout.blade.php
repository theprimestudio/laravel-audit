<!DOCTYPE html>
<html lang="en" data-theme="{{ config('audit.theme_mode', 'light') }}">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ config('audit.product_name', 'Laravel Audit') }} - The Prime Studio</title>
    <!-- FontAwesome 6 CDN -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        :root {
            --bg-color: #0f172a;
            --card-bg: #1e293b;
            --text-primary: #f8fafc;
            --text-secondary: #94a3b8;
            --border-color: #334155;
            --primary: {{ config('audit.primary_color', '#000000') }};
            --accent: {{ config('audit.accent_color', '#333333') }};
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --info: #06b6d4;
            --sidebar-width: 260px;
            --radius: 12px;
            --font: 'Outfit', system-ui, -apple-system, sans-serif;
        }

        [data-theme="light"] {
            --bg-color: #f8fafc;
            --card-bg: #ffffff;
            --text-primary: #0f172a;
            --text-secondary: #64748b;
            --border-color: #e2e8f0;
        }

        /* Pagination SVG fix */
        nav[role="navigation"] svg { width: 1.25rem; height: 1.25rem; }
        .w-5 { width: 1.25rem; }
        .h-5 { height: 1.25rem; }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background-color: var(--bg-color);
            color: var(--text-primary);
            font-family: var(--font);
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar styling */
        .sidebar {
            width: var(--sidebar-width);
            background-color: var(--card-bg);
            border-right: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            z-index: 100;
        }

        .brand {
            padding: 24px;
            font-size: 1.25rem;
            font-weight: 700;
            letter-spacing: -0.025em;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .brand i {
            color: var(--primary);
        }

        .menu {
            list-style: none;
            padding: 16px;
            display: flex;
            flex-direction: column;
            gap: 6px;
            flex-grow: 1;
            overflow-y: auto;
        }

        .menu-item a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            color: var(--text-secondary);
            text-decoration: none;
            border-radius: var(--radius);
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .menu-item a:hover, .menu-item.active a {
            background-color: rgba(99, 102, 241, 0.1);
            color: var(--primary);
        }

        .menu-item a i {
            width: 20px;
            text-align: center;
            font-size: 1.1em;
        }

        /* Footer in sidebar */
        .sidebar-footer {
            padding: 16px;
            border-top: 1px solid var(--border-color);
            text-align: center;
            font-size: 0.8rem;
            color: var(--text-secondary);
        }
        
        .sidebar-footer a {
            color: var(--primary);
            text-decoration: none;
            font-weight: 600;
        }

        .sidebar-footer a:hover {
            text-decoration: underline;
        }

        /* Main content layout */
        .main {
            margin-left: var(--sidebar-width);
            flex-grow: 1;
            padding: 0 40px 40px 40px;
            max-width: 1400px;
        }

        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: flex-end;
            padding: 16px 0;
            margin-bottom: 24px;
            border-bottom: 1px solid var(--border-color);
        }

        .top-bar a {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--text-secondary);
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 500;
            transition: color 0.2s;
        }

        .top-bar a:hover {
            color: var(--primary);
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 32px;
        }

        .title h1 {
            font-size: 1.875rem;
            font-weight: 700;
            letter-spacing: -0.025em;
        }

        .title p {
            color: var(--text-secondary);
            margin-top: 4px;
        }

        /* Button styles */
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 10px 18px;
            font-weight: 600;
            border-radius: var(--radius);
            border: none;
            cursor: pointer;
            transition: all 0.2s ease;
            text-decoration: none;
            gap: 8px;
        }

        .btn-primary {
            background-color: var(--primary);
            color: white;
        }

        .btn-primary:hover {
            opacity: 0.9;
        }

        .btn-secondary {
            background-color: transparent;
            border: 1px solid var(--border-color);
            color: var(--text-primary);
        }

        .btn-secondary:hover {
            background-color: rgba(255,255,255,0.05);
        }

        /* Grid cards */
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px;
            margin-bottom: 32px;
        }

        .card {
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: var(--radius);
            padding: 24px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -2px rgba(0, 0, 0, 0.1);
        }

        .card-title {
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--text-secondary);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 12px;
        }

        .card-value {
            font-size: 2.25rem;
            font-weight: 700;
            margin-bottom: 8px;
        }

        .card-footer {
            font-size: 0.875rem;
            color: var(--text-secondary);
        }

        /* Score wheel / Circle */
        .score-circle {
            position: relative;
            width: 120px;
            height: 120px;
        }

        /* Table design */
        .table-container {
            background-color: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: var(--radius);
            overflow: hidden;
            margin-top: 24px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th {
            background-color: rgba(0, 0, 0, 0.05);
            padding: 16px 24px;
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--text-secondary);
            border-bottom: 1px solid var(--border-color);
        }

        td {
            padding: 16px 24px;
            font-size: 0.95rem;
            border-bottom: 1px solid var(--border-color);
        }

        tr:last-child td {
            border-bottom: none;
        }

        /* Badges */
        .badge {
            display: inline-flex;
            align-items: center;
            padding: 4px 10px;
            border-radius: 9999px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .badge-critical { background: rgba(239, 68, 68, 0.15); color: var(--danger); }
        .badge-high { background: rgba(245, 158, 11, 0.15); color: var(--warning); }
        .badge-medium { background: rgba(59, 130, 246, 0.15); color: var(--accent); }
        .badge-low { background: rgba(16, 185, 129, 0.15); color: var(--success); }
        .badge-info { background: rgba(6, 182, 212, 0.15); color: var(--info); }

        /* Notification banner */
        .alert {
            padding: 16px;
            border-radius: var(--radius);
            margin-bottom: 24px;
            border: 1px solid transparent;
            margin-top: 24px;
        }
        .alert-success {
            background-color: rgba(16, 185, 129, 0.1);
            border-color: var(--success);
            color: var(--success);
        }
        .alert-error {
            background-color: rgba(239, 68, 68, 0.1);
            border-color: var(--danger);
            color: var(--danger);
        }
    </style>
    @stack('styles')
</head>
<body>

    <aside class="sidebar">
        <div class="brand">
            <i class="fa-solid fa-shield-halved"></i> {{ config('audit.product_name', 'Laravel Audit') }}
        </div>
        <ul class="menu">
            @can(config('audit.permissions.dashboard'))
                <li class="menu-item {{ request()->routeIs('audit.dashboard') ? 'active' : '' }}">
                    <a href="{{ route('audit.dashboard') }}"><i class="fa-solid fa-chart-pie"></i> Overview</a>
                </li>
            @endcan

            @can(config('audit.permissions.websites'))
                <li class="menu-item {{ request()->routeIs('audit.websites') ? 'active' : '' }}">
                    <a href="{{ route('audit.websites') }}"><i class="fa-solid fa-globe"></i> Websites</a>
                </li>
            @endcan

            @can(config('audit.permissions.seo'))
                <li class="menu-item {{ request()->routeIs('audit.seo') ? 'active' : '' }}">
                    <a href="{{ route('audit.seo') }}"><i class="fa-solid fa-magnifying-glass"></i> SEO Audit</a>
                </li>
            @endcan

            @can(config('audit.permissions.security'))
                <li class="menu-item {{ request()->routeIs('audit.security') ? 'active' : '' }}">
                    <a href="{{ route('audit.security') }}"><i class="fa-solid fa-lock"></i> Security</a>
                </li>
            @endcan

            @can(config('audit.permissions.performance'))
                <li class="menu-item {{ request()->routeIs('audit.performance') ? 'active' : '' }}">
                    <a href="{{ route('audit.performance') }}"><i class="fa-solid fa-bolt"></i> Performance</a>
                </li>
            @endcan

            @can(config('audit.permissions.laravel'))
                <li class="menu-item {{ request()->routeIs('audit.laravel') ? 'active' : '' }}">
                    <a href="{{ route('audit.laravel') }}"><i class="fa-solid fa-wrench"></i> Laravel Health</a>
                </li>
            @endcan

            @can(config('audit.permissions.api'))
                <li class="menu-item {{ request()->routeIs('audit.api') ? 'active' : '' }}">
                    <a href="{{ route('audit.api') }}"><i class="fa-solid fa-plug"></i> API Monitor</a>
                </li>
            @endcan

            @can(config('audit.permissions.issues'))
                <li class="menu-item {{ request()->routeIs('audit.issues.*') ? 'active' : '' }}">
                    <a href="{{ route('audit.issues.index') }}"><i class="fa-solid fa-triangle-exclamation"></i> Issues</a>
                </li>
            @endcan

            @can(config('audit.permissions.audits'))
                <li class="menu-item {{ request()->routeIs('audit.audits.*') ? 'active' : '' }}">
                    <a href="{{ route('audit.audits.index') }}"><i class="fa-solid fa-clock-rotate-left"></i> Audits History</a>
                </li>
            @endcan

            @can(config('audit.permissions.reports'))
                <li class="menu-item {{ request()->routeIs('audit.reports.*') ? 'active' : '' }}">
                    <a href="{{ route('audit.reports.index') }}"><i class="fa-solid fa-file-lines"></i> Reports</a>
                </li>
            @endcan

            @can(config('audit.permissions.settings'))
                <li class="menu-item {{ request()->routeIs('audit.settings.*') ? 'active' : '' }}">
                    <a href="{{ route('audit.settings.index') }}"><i class="fa-solid fa-gear"></i> Settings</a>
                </li>
            @endcan
        </ul>
        <div class="sidebar-footer">
            Developed by <a href="https://theprimestudio.com" target="_blank">The Prime Studio</a>
        </div>
    </aside>

    <main class="main">
        <div class="top-bar">
            <a href="{{ url(config('audit.admin_panel_url', '/admin')) }}">
                <i class="fa-solid fa-arrow-left"></i> Back to Admin Panel
            </a>
        </div>

        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif

        @if (session('error'))
            <div class="alert alert-error">
                {{ session('error') }}
            </div>
        @endif

        @yield('content')
    </main>

    @stack('scripts')
</body>
</html>
