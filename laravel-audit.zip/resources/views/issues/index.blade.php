@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>Diagnostic Issues Log</h1>
        <p>List of all discovered problems, security risks, SEO errors, and optimization items.</p>
    </div>
</div>

<div class="card" style="margin-bottom: 24px;">
    <form action="{{ route('audit.issues.index') }}" method="GET" style="display: flex; gap: 16px; flex-wrap: wrap;">
        <input type="text" name="search" value="{{ request('search') }}" placeholder="Search issues..." class="btn btn-secondary" style="text-align: left; padding: 10px 16px; flex-grow: 1; min-width: 200px; color: var(--text-primary);">
        
        <select name="category" class="btn btn-secondary" onchange="this.form.submit()">
            <option value="">All Categories</option>
            <option value="security" {{ request('category') === 'security' ? 'selected' : '' }}>Security</option>
            <option value="seo" {{ request('category') === 'seo' ? 'selected' : '' }}>SEO</option>
            <option value="performance" {{ request('category') === 'performance' ? 'selected' : '' }}>Performance</option>
            <option value="reliability" {{ request('category') === 'reliability' ? 'selected' : '' }}>Reliability</option>
            <option value="laravel" {{ request('category') === 'laravel' ? 'selected' : '' }}>Laravel</option>
        </select>

        <select name="severity" class="btn btn-secondary" onchange="this.form.submit()">
            <option value="">All Severities</option>
            <option value="critical" {{ request('severity') === 'critical' ? 'selected' : '' }}>Critical</option>
            <option value="high" {{ request('severity') === 'high' ? 'selected' : '' }}>High</option>
            <option value="medium" {{ request('severity') === 'medium' ? 'selected' : '' }}>Medium</option>
            <option value="low" {{ request('severity') === 'low' ? 'selected' : '' }}>Low</option>
        </select>

        <select name="status" class="btn btn-secondary" onchange="this.form.submit()">
            <option value="open" {{ request('status') === 'open' ? 'selected' : '' }}>Open / Active</option>
            <option value="acknowledged" {{ request('status') === 'acknowledged' ? 'selected' : '' }}>Acknowledged</option>
            <option value="ignored" {{ request('status') === 'ignored' ? 'selected' : '' }}>Ignored</option>
            <option value="resolved" {{ request('status') === 'resolved' ? 'selected' : '' }}>Resolved</option>
        </select>

        <button type="submit" class="btn btn-primary">Filter</button>
    </form>
</div>

<div class="card">
    <div class="table-container" style="margin-top: 0;">
        <table>
            <thead>
                <tr>
                    <th>Category</th>
                    <th>Severity</th>
                    <th>Issue Title</th>
                    <th>URL</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($issues as $issue)
                    <tr>
                        <td><span class="badge badge-info">{{ $issue->category }}</span></td>
                        <td><span class="badge badge-{{ $issue->severity }}">{{ $issue->severity }}</span></td>
                        <td>
                            <div style="font-weight: 600;">{{ $issue->title }}</div>
                            <div style="font-size: 0.85rem; color: var(--text-secondary); margin-top: 4px;">{{ $issue->description }}</div>
                            @if($issue->recommendation)
                                <div style="font-size: 0.85rem; color: var(--success); margin-top: 4px;"><i class="fa-solid fa-lightbulb"></i> Recommendation: {{ $issue->recommendation }}</div>
                            @endif
                        </td>
                        <td>
                            <span style="font-size: 0.85rem; color: var(--text-secondary);">{{ $issue->url ?: 'Global' }}</span>
                        </td>
                        <td>
                            <div style="display: flex; gap: 8px;">
                                @if($issue->status === 'open')
                                    <form action="{{ route('audit.issues.resolve', $issue) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="btn btn-secondary" style="padding: 6px 12px; font-size: 0.75rem;"><i class="fa-solid fa-check"></i> Resolve</button>
                                    </form>
                                    <form action="{{ route('audit.issues.ignore', $issue) }}" method="POST">
                                        @csrf
                                        <button type="submit" class="btn btn-secondary" style="padding: 6px 12px; font-size: 0.75rem;"><i class="fa-solid fa-eye-slash"></i> Ignore</button>
                                    </form>
                                @endif
                                <form action="{{ route('audit.issues.delete', $issue) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this issue?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-secondary" style="padding: 6px 12px; font-size: 0.75rem; color: var(--danger); border-color: rgba(239, 68, 68, 0.2);"><i class="fa-solid fa-trash"></i> Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="5" style="text-align: center; color: var(--text-secondary); padding: 40px 0;">No matching issues found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    
    <div style="margin-top: 24px;">
        {{ $issues->links() }}
    </div>
</div>
@endsection
