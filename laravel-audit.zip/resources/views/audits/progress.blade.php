@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>Audit Progress</h1>
        <p>Live tracking of audit execution phases.</p>
    </div>
</div>

<div class="card" style="max-width: 800px;">
    <div style="text-align: center; margin-bottom: 32px;">
        <div style="font-size: 3rem; color: var(--primary); margin-bottom: 16px;">
            <i class="fa-solid fa-rotate fa-spin" id="spinner-icon"></i>
        </div>
        <h2 id="progress-title">Audit Run #{{ $run->id }}</h2>
        <p style="color: var(--text-secondary); margin-top: 4px;" id="progress-status">
            Status: <strong style="color: var(--primary);">{{ ucfirst($run->status) }}</strong>
        </p>
    </div>

    {{-- Overall progress bar --}}
    <div style="margin-bottom: 32px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 8px;">
            <span style="font-weight: 600;">Overall Progress</span>
            <span id="progress-percent" style="font-weight: 700; color: var(--primary);">{{ $run->progress_percent ?? 0 }}%</span>
        </div>
        <div style="background-color: var(--border-color); height: 12px; border-radius: 6px; overflow: hidden;">
            <div id="progress-bar" style="background-color: var(--primary); height: 100%; width: {{ $run->progress_percent ?? 0 }}%; transition: width 0.5s ease; border-radius: 6px;"></div>
        </div>
        <p id="progress-message" style="font-size: 0.875rem; color: var(--text-secondary); margin-top: 8px;">
            {{ $run->progress_message ?? 'Initializing...' }}
        </p>
    </div>

    {{-- Phase breakdown --}}
    <div style="display: flex; flex-direction: column; gap: 12px;">
        <div class="phase-row" id="phase-crawl">
            <div style="display: flex; align-items: center; gap: 12px;">
                <i class="fa-solid fa-spider" style="width: 20px; text-align: center; color: var(--text-secondary);"></i>
                <span style="font-weight: 600; flex-grow: 1;">Crawling</span>
                <span class="badge badge-info phase-badge" id="phase-crawl-badge">Pending</span>
            </div>
            <div style="font-size: 0.8rem; color: var(--text-secondary); margin-left: 32px; margin-top: 4px;" id="phase-crawl-detail">
                Discovering pages and URLs across the site.
            </div>
        </div>

        <div style="border-top: 1px solid var(--border-color);"></div>

        <div class="phase-row" id="phase-audit">
            <div style="display: flex; align-items: center; gap: 12px;">
                <i class="fa-solid fa-magnifying-glass" style="width: 20px; text-align: center; color: var(--text-secondary);"></i>
                <span style="font-weight: 600; flex-grow: 1;">SEO, Security & Performance Audits</span>
                <span class="badge badge-info phase-badge" id="phase-audit-badge">Pending</span>
            </div>
            <div style="font-size: 0.8rem; color: var(--text-secondary); margin-left: 32px; margin-top: 4px;" id="phase-audit-detail">
                Running checks on each crawled URL.
            </div>
        </div>

        <div style="border-top: 1px solid var(--border-color);"></div>

        <div class="phase-row" id="phase-routes">
            <div style="display: flex; align-items: center; gap: 12px;">
                <i class="fa-solid fa-route" style="width: 20px; text-align: center; color: var(--text-secondary);"></i>
                <span style="font-weight: 600; flex-grow: 1;">Route Logging</span>
                <span class="badge badge-info phase-badge" id="phase-routes-badge">Pending</span>
            </div>
            <div style="font-size: 0.8rem; color: var(--text-secondary); margin-left: 32px; margin-top: 4px;" id="phase-routes-detail">
                Cataloging all registered application routes.
            </div>
        </div>

        <div style="border-top: 1px solid var(--border-color);"></div>

        <div class="phase-row" id="phase-scoring">
            <div style="display: flex; align-items: center; gap: 12px;">
                <i class="fa-solid fa-chart-line" style="width: 20px; text-align: center; color: var(--text-secondary);"></i>
                <span style="font-weight: 600; flex-grow: 1;">Scoring</span>
                <span class="badge badge-info phase-badge" id="phase-scoring-badge">Pending</span>
            </div>
            <div style="font-size: 0.8rem; color: var(--text-secondary); margin-left: 32px; margin-top: 4px;" id="phase-scoring-detail">
                Computing final audit scores.
            </div>
        </div>
    </div>

    <div style="margin-top: 32px; display: flex; gap: 12px;">
        <a href="{{ route('audit.dashboard') }}" class="btn btn-secondary">
            <i class="fa-solid fa-arrow-left"></i> Dashboard
        </a>
    </div>
</div>

<script>
    const pollUrl = "{{ route('audit.audits.progress-data') }}";
    let pollInterval;

    function updatePhases(percent, message) {
        // Phase: Crawl (0-40%)
        const crawlBadge = document.getElementById('phase-crawl-badge');
        const crawlDetail = document.getElementById('phase-crawl-detail');
        if (percent >= 40) {
            crawlBadge.textContent = 'Complete';
            crawlBadge.className = 'badge badge-low';
        } else if (percent >= 2) {
            crawlBadge.textContent = 'Running';
            crawlBadge.className = 'badge badge-medium';
            crawlDetail.textContent = message;
        }

        // Phase: Audit (40-80%)
        const auditBadge = document.getElementById('phase-audit-badge');
        const auditDetail = document.getElementById('phase-audit-detail');
        if (percent >= 80) {
            auditBadge.textContent = 'Complete';
            auditBadge.className = 'badge badge-low';
        } else if (percent >= 42) {
            auditBadge.textContent = 'Running';
            auditBadge.className = 'badge badge-medium';
            auditDetail.textContent = message;
        }

        // Phase: Routes (80-90%)
        const routesBadge = document.getElementById('phase-routes-badge');
        const routesDetail = document.getElementById('phase-routes-detail');
        if (percent >= 90) {
            routesBadge.textContent = 'Complete';
            routesBadge.className = 'badge badge-low';
        } else if (percent >= 82) {
            routesBadge.textContent = 'Running';
            routesBadge.className = 'badge badge-medium';
            routesDetail.textContent = message;
        }

        // Phase: Scoring (90-100%)
        const scoringBadge = document.getElementById('phase-scoring-badge');
        const scoringDetail = document.getElementById('phase-scoring-detail');
        if (percent >= 100) {
            scoringBadge.textContent = 'Complete';
            scoringBadge.className = 'badge badge-low';
        } else if (percent >= 92) {
            scoringBadge.textContent = 'Running';
            scoringBadge.className = 'badge badge-medium';
            scoringDetail.textContent = message;
        }
    }

    function poll() {
        fetch(pollUrl)
            .then(r => r.json())
            .then(data => {
                if (data.status === 'none') return;

                document.getElementById('progress-percent').textContent = data.progress_percent + '%';
                document.getElementById('progress-bar').style.width = data.progress_percent + '%';
                document.getElementById('progress-message').textContent = data.progress_message;
                document.getElementById('progress-status').innerHTML = 'Status: <strong style="color: var(--primary);">' + data.status.charAt(0).toUpperCase() + data.status.slice(1) + '</strong>';

                updatePhases(data.progress_percent, data.progress_message);

                if (data.status === 'completed') {
                    clearInterval(pollInterval);
                    document.getElementById('spinner-icon').className = 'fa-solid fa-circle-check';
                    document.getElementById('spinner-icon').style.color = 'var(--success)';
                    document.getElementById('progress-message').textContent = 'Audit completed successfully! Redirecting...';
                    setTimeout(() => { window.location.href = "{{ route('audit.dashboard') }}"; }, 2000);
                } else if (data.status === 'failed') {
                    clearInterval(pollInterval);
                    document.getElementById('spinner-icon').className = 'fa-solid fa-circle-xmark';
                    document.getElementById('spinner-icon').style.color = 'var(--danger)';
                }
            })
            .catch(() => {});
    }

    pollInterval = setInterval(poll, 2000);
    poll();
</script>
@endsection
