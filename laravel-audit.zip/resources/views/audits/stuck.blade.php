@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>Unfinished Audit Detected</h1>
        <p>An audit from a previous session was found with status <strong>{{ ucfirst($stuckRun->status) }}</strong>. Please resolve it before starting a new one.</p>
    </div>
</div>

<div class="card" style="max-width: 700px;">
    <div style="display: flex; align-items: center; gap: 16px; margin-bottom: 24px;">
        <div style="font-size: 2.5rem; color: var(--warning);"><i class="fa-solid fa-triangle-exclamation"></i></div>
        <div>
            <h2 style="margin-bottom: 4px;">Audit Run #{{ $stuckRun->id }}</h2>
            <div style="color: var(--text-secondary); font-size: 0.875rem;">
                Started: {{ $stuckRun->started_at ? $stuckRun->started_at->format('Y-m-d H:i:s') : 'Unknown' }}
                &mdash; Status: <span class="badge badge-high">{{ ucfirst($stuckRun->status) }}</span>
            </div>
            @if($stuckRun->progress_message)
                <div style="color: var(--text-secondary); font-size: 0.875rem; margin-top: 4px;">
                    Last activity: {{ $stuckRun->progress_message }} ({{ $stuckRun->progress_percent ?? 0 }}%)
                </div>
            @endif
        </div>
    </div>

    <p style="margin-bottom: 24px; color: var(--text-secondary);">
        Choose how to handle this audit before starting a new one:
    </p>

    <div style="display: flex; gap: 12px; flex-wrap: wrap;">
        <form action="{{ route('audit.audits.resolve-stuck') }}" method="POST">
            @csrf
            <input type="hidden" name="run_id" value="{{ $stuckRun->id }}">
            <input type="hidden" name="action" value="mark_failed">
            <button type="submit" class="btn btn-secondary" style="border-color: var(--danger); color: var(--danger);">
                <i class="fa-solid fa-xmark"></i> Mark as Failed
            </button>
        </form>

        <form action="{{ route('audit.audits.resolve-stuck') }}" method="POST">
            @csrf
            <input type="hidden" name="run_id" value="{{ $stuckRun->id }}">
            <input type="hidden" name="action" value="mark_completed">
            <button type="submit" class="btn btn-secondary" style="border-color: var(--success); color: var(--success);">
                <i class="fa-solid fa-check"></i> Mark as Completed
            </button>
        </form>

        <form action="{{ route('audit.audits.resolve-stuck') }}" method="POST" onsubmit="return confirm('This will permanently delete this audit run and all its data. Continue?')">
            @csrf
            <input type="hidden" name="run_id" value="{{ $stuckRun->id }}">
            <input type="hidden" name="action" value="delete">
            <button type="submit" class="btn btn-secondary" style="border-color: var(--warning); color: var(--warning);">
                <i class="fa-solid fa-trash"></i> Delete Entirely
            </button>
        </form>
    </div>

    <div style="margin-top: 24px;">
        <a href="{{ route('audit.audits.index') }}" class="btn btn-secondary" style="font-size: 0.875rem;">
            <i class="fa-solid fa-arrow-left"></i> Back to Audits
        </a>
    </div>
</div>
@endsection
