@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>Audit Runs History</h1>
        <p>List of all historical audits, overall scores, crawled items and status reports.</p>
    </div>
    <div>
        @can(config('audit.permissions.actions.run_audit'))
            <form action="{{ route('audit.audits.run') }}" method="POST">
                @csrf
                <button type="submit" class="btn btn-primary">Start New Audit</button>
            </form>
        @endcan
    </div>
</div>

<div class="card">
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Run ID</th>
                    <th>Status</th>
                    <th>Overall Score</th>
                    <th>Crawled URLs</th>
                    <th>Detected Issues</th>
                    <th>Execution Duration</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse($runs as $run)
                    <tr>
                        <td><strong>#{{ $run->id }}</strong></td>
                        <td>
                            <span class="badge badge-{{ $run->status === 'completed' ? 'low' : ($run->status === 'failed' ? 'critical' : 'info') }}">
                                {{ $run->status }}
                            </span>
                        </td>
                        <td>
                            <span style="font-weight: bold; font-size: 1.1rem; color: var(--primary);">
                                {{ $run->overall_score ? $run->overall_score . '%' : 'N/A' }}
                            </span>
                        </td>
                        <td>{{ $run->urls_crawled }} URLs</td>
                        <td>
                            <span class="badge badge-{{ $run->issues_found > 0 ? 'high' : 'low' }}">
                                {{ $run->issues_found }} issues
                            </span>
                        </td>
                        <td>
                            {{ $run->completed_at ? $run->completed_at->diffInSeconds($run->started_at) . ' sec' : 'N/A' }}
                        </td>
                        <td>
                            <div style="display: flex; gap: 8px;">
                                <form action="{{ route('audit.audits.delete', $run) }}" method="POST" onsubmit="return confirm('Are you sure you want to delete this audit run history?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-secondary" style="padding: 6px 12px; font-size: 0.75rem; color: var(--danger); border-color: rgba(239, 68, 68, 0.2);">Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" style="text-align: center; color: var(--text-secondary);">No audits have been executed yet.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    
    <div style="margin-top: 24px;">
        {{ $runs->links() }}
    </div>
</div>
@endsection
