@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>Platform Settings</h1>
        <p>Customize UI, themes, notification bounds, crawl depth limits, and security thresholds.</p>
    </div>
</div>

<div class="card" style="max-width: 800px;">
    <form action="{{ route('audit.settings.update') }}" method="POST">
        @csrf
        
        <div style="display: flex; flex-direction: column; gap: 20px; margin-bottom: 24px;">
            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 6px;">Product / Platform Name</label>
                <input type="text" name="product_name" value="{{ $settings['product_name'] ?? 'Laravel Audit' }}" class="btn btn-secondary" style="text-align: left; width: 100%; color: var(--text-primary);">
            </div>

            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 6px;">Admin Panel URL (for "Back" button)</label>
                <input type="text" name="admin_panel_url" value="{{ $settings['admin_panel_url'] ?? config('audit.admin_panel_url', '/admin') }}" class="btn btn-secondary" style="text-align: left; width: 100%; color: var(--text-primary);">
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div>
                    <label style="display: block; font-weight: 600; margin-bottom: 6px;">Primary Theme Color</label>
                    <input type="color" name="primary_color" value="{{ $settings['primary_color'] ?? '#000000' }}" style="width: 100%; height: 42px; border: 1px solid var(--border-color); border-radius: var(--radius); background: transparent; cursor: pointer;">
                </div>
                <div>
                    <label style="display: block; font-weight: 600; margin-bottom: 6px;">Accent Color</label>
                    <input type="color" name="accent_color" value="{{ $settings['accent_color'] ?? '#333333' }}" style="width: 100%; height: 42px; border: 1px solid var(--border-color); border-radius: var(--radius); background: transparent; cursor: pointer;">
                </div>
            </div>

            <div>
                <label style="display: block; font-weight: 600; margin-bottom: 6px;">Theme Mode</label>
                <select name="theme_mode" class="btn btn-secondary" style="text-align: left; width: 100%; color: var(--text-primary);">
                    <option value="light" {{ ($settings['theme_mode'] ?? 'light') === 'light' ? 'selected' : '' }}>Light Theme</option>
                    <option value="dark" {{ ($settings['theme_mode'] ?? 'light') === 'dark' ? 'selected' : '' }}>Dark Theme</option>
                </select>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <div>
                    <label style="display: block; font-weight: 600; margin-bottom: 6px;">Crawl Concurrency</label>
                    <input type="number" name="crawler_concurrency" value="{{ $settings['crawler_concurrency'] ?? 3 }}" class="btn btn-secondary" style="text-align: left; width: 100%; color: var(--text-primary);">
                </div>
                <div>
                    <label style="display: block; font-weight: 600; margin-bottom: 6px;">Max URLs to Crawl</label>
                    <input type="number" name="crawler_max_urls" value="{{ $settings['crawler_max_urls'] ?? 100 }}" class="btn btn-secondary" style="text-align: left; width: 100%; color: var(--text-primary);">
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Save Settings</button>
    </form>
</div>
@endsection
