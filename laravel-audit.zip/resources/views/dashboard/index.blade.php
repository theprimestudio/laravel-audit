@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>Dashboard Overview</h1>
        <p>Overall health and diagnostic scores for your Laravel application.</p>
    </div>
    <div>
        @can(config('audit.permissions.actions.run_audit'))
            <form action="{{ route('audit.audits.run') }}" method="POST">
                @csrf
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-rotate-right"></i> Run New Audit</button>
            </form>
        @endcan
    </div>
</div>

@php
    $activeRun = \ThePrimeStudio\Audit\Models\AuditRun::whereIn('status', ['running', 'pending'])->orderBy('id', 'desc')->first();
@endphp

@if($activeRun)
<div class="card" style="background: var(--card-bg); border: 1px solid var(--primary); padding: 16px 24px; margin-bottom: 24px; display: flex; align-items: center; justify-content: space-between; gap: 16px;">
    <div style="display: flex; align-items: center; gap: 12px;">
        <i class="fa-solid fa-rotate fa-spin" style="color: var(--primary); font-size: 1.25rem;"></i>
        <div>
            <strong>Audit Run #{{ $activeRun->id }} is in progress</strong>
            <div style="font-size: 0.8rem; color: var(--text-secondary);">{{ $activeRun->progress_message ?? 'Starting...' }} &mdash; {{ $activeRun->progress_percent ?? 0 }}%</div>
        </div>
    </div>
    <a href="{{ route('audit.audits.progress') }}" class="btn btn-primary" style="white-space: nowrap;">
        <i class="fa-solid fa-eye"></i> View Progress
    </a>
</div>
@endif
    <div class="grid">
        <div class="card" style="display: flex; align-items: center; gap: 20px;">
            <div style="flex-grow: 1;">
                <div class="card-title">Overall Score</div>
                <div class="card-value" style="color: var(--primary);">{{ $lastRun->overall_score ?? 'N/A' }}%</div>
                <div class="card-footer">Based on 5 audit categories</div>
            </div>
            <div>
                <!-- Inline SVG Score Ring -->
                <svg width="80" height="80" viewBox="0 0 36 36">
                    <path class="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="var(--border-color)" stroke-width="3"/>
                    <path class="circle" stroke-dasharray="{{ $lastRun->overall_score ?? 0 }}, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke="var(--primary)" stroke-width="3" stroke-linecap="round"/>
                </svg>
            </div>
        </div>

        <div class="card">
            <div class="card-title">Security Score</div>
            <div class="card-value" style="color: var(--danger);">{{ $lastRun->security_score ?? 'N/A' }}%</div>
            <div class="card-footer">Weight: 30%</div>
        </div>

        <div class="card">
            <div class="card-title">Technical SEO Score</div>
            <div class="card-value" style="color: var(--warning);">{{ $lastRun->seo_score ?? 'N/A' }}%</div>
            <div class="card-footer">Weight: 25%</div>
        </div>

        <div class="card">
            <div class="card-title">Performance Score</div>
            <div class="card-value" style="color: var(--success);">{{ $lastRun->performance_score ?? 'N/A' }}%</div>
            <div class="card-footer">Weight: 20%</div>
        </div>
    </div>

    <div class="grid">
        <div class="card" style="grid-column: span 2;">
            <h3 style="margin-bottom: 20px;">Recent Diagnostic Issues</h3>
            @if($lastRun->issues()->count() > 0)
                <div class="table-container" style="margin-top: 0;">
                    <table>
                        <thead>
                            <tr>
                                <th>Category</th>
                                <th>Severity</th>
                                <th>Issue</th>
                                <th>URL</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($lastRun->issues()->take(5)->get() as $issue)
                                <tr>
                                    <td><span class="badge badge-info">{{ $issue->category }}</span></td>
                                    <td><span class="badge badge-{{ $issue->severity }}">{{ $issue->severity }}</span></td>
                                    <td style="font-weight: 600;">{{ $issue->title }}</td>
                                    <td style="color: var(--text-secondary);">{{ $issue->url ?: 'Global' }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div style="margin-top: 16px; text-align: right;">
                    <a href="{{ route('audit.issues.index') }}" class="btn btn-secondary" style="font-size: 0.875rem;">View All Issues</a>
                </div>
            @else
                <p style="color: var(--text-secondary);">No issues found! Your application is in pristine condition. <i class="fa-solid fa-party-horn"></i></p>
            @endif
        </div>

        <div class="card">
            <h3 style="margin-bottom: 20px;">Audit Summary</h3>
            <div style="display: flex; flex-direction: column; gap: 16px;">
                <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-color); padding-bottom: 8px;">
                    <span style="color: var(--text-secondary);">URLs Crawled</span>
                    <span style="font-weight: bold;">{{ $lastRun->urls_crawled }}</span>
                </div>
                <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-color); padding-bottom: 8px;">
                    <span style="color: var(--text-secondary);">Laravel Health</span>
                    <span style="font-weight: bold; color: var(--success);">{{ $lastRun->laravel_score ?? 'N/A' }}%</span>
                </div>
                <div style="display: flex; justify-content: space-between; border-bottom: 1px solid var(--border-color); padding-bottom: 8px;">
                    <span style="color: var(--text-secondary);">Reliability Score</span>
                    <span style="font-weight: bold; color: var(--accent);">{{ $lastRun->reliability_score ?? 'N/A' }}%</span>
                </div>
                <div style="display: flex; justify-content: space-between; padding-bottom: 8px;">
                    <span style="color: var(--text-secondary);">Completed At</span>
                    <span style="font-weight: bold;">{{ $lastRun->completed_at ? $lastRun->completed_at->format('Y-m-d H:i') : 'N/A' }}</span>
                </div>
            </div>
        </div>
    </div>
@else
    <div class="card" style="text-align: center; padding: 60px 24px;">
        <div style="font-size: 3rem; margin-bottom: 20px; color: var(--primary);"><i class="fa-solid fa-shield-halved"></i></div>
        <h2>No Audit Data Available</h2>
        <p style="color: var(--text-secondary); margin-bottom: 24px;">Run your first website and application audit to generate insights.</p>
        @can(config('audit.permissions.actions.run_audit'))
            <form action="{{ route('audit.audits.run') }}" method="POST">
                @csrf
                <button type="submit" class="btn btn-primary">Start Diagnostic Audit</button>
            </form>
        @endcan
    </div>
@endif

@endsection
