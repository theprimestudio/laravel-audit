@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>API Diagnostics & Performance</h1>
        <p>Monitor status, latency, CORS setup, and JSON structure validity of API endpoints.</p>
    </div>
</div>

<div class="card">
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Endpoint URL</th>
                    <th>Status</th>
                    <th>Response Time</th>
                    <th>Size</th>
                    <th>Content Type</th>
                </tr>
            </thead>
            <tbody>
                @forelse($apiResults as $url)
                    <tr>
                        <td>
                            <a href="{{ $url->url }}" target="_blank" style="color: var(--primary); text-decoration: none; font-family: monospace;">{{ $url->path }}</a>
                        </td>
                        <td>
                            @if($url->httpResult)
                                <span class="badge badge-{{ $url->httpResult->status_code >= 400 ? 'critical' : 'low' }}">
                                    {{ $url->httpResult->status_code ?: 'N/A' }}
                                </span>
                            @else
                                <span class="badge badge-info">Pending</span>
                            @endif
                        </td>
                        <td>{{ $url->httpResult?->response_time_ms ? $url->httpResult->response_time_ms . ' ms' : 'N/A' }}</td>
                        <td>{{ $url->httpResult?->response_size_bytes ? number_format($url->httpResult->response_size_bytes / 1024, 2) . ' KB' : 'N/A' }}</td>
                        <td>{{ $url->httpResult?->content_type ?: 'N/A' }}</td>
                    </tr>
                @empty
                    @foreach($registeredApiRoutes as $route)
                        <tr>
                            <td>
                                <span style="color: var(--primary); font-family: monospace;">/{{ $route->uri }}</span>
                                <br><small style="color: var(--text-secondary);">Registered Route</small>
                            </td>
                            <td><span class="badge badge-info">Not Crawled</span></td>
                            <td>N/A</td>
                            <td>N/A</td>
                            <td>N/A</td>
                        </tr>
                    @endforeach
                    @if($registeredApiRoutes->isEmpty())
                        <tr>
                            <td colspan="5" style="text-align: center; color: var(--text-secondary);">No API crawl results found. Ensure your endpoints are auto-discovered or prefix-mapped.</td>
                        </tr>
                    @endif
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
