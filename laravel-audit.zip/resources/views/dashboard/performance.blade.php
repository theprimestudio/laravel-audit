@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>Performance Profiling</h1>
        <p>Measure page speed, TTFB, database query count, and memory overhead.</p>
    </div>
</div>

<div class="card">
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>URL</th>
                    <th>Response Time (TTFB)</th>
                    <th>Database Queries</th>
                    <th>Memory Usage</th>
                </tr>
            </thead>
            <tbody>
                @forelse($performanceResults as $url)
                    @if($url->performanceResult)
                        <tr>
                            <td><a href="{{ $url->url }}" target="_blank" style="color: var(--primary); text-decoration: none;">{{ $url->path ?: '/' }}</a></td>
                            <td>
                                <span style="font-weight: 600; color: {{ $url->httpResult?->response_time_ms > 800 ? 'var(--danger)' : 'var(--success)' }}">
                                    {{ $url->httpResult?->response_time_ms ?: 'N/A' }} ms
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-{{ $url->performanceResult->query_count > 15 ? 'high' : 'low' }}">
                                    {{ $url->performanceResult->query_count }} queries ({{ $url->performanceResult->query_time_ms }} ms)
                                </span>
                            </td>
                            <td>
                                {{ number_format($url->performanceResult->memory_usage_bytes / 1024 / 1024, 2) }} MB
                            </td>
                        </tr>
                    @endif
                @empty
                    <tr>
                        <td colspan="4" style="text-align: center; color: var(--text-secondary);">No performance audit results found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
