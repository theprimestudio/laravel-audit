@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>Crawled Websites & URLs</h1>
        <p>List of all discovered internal and external URLs, response metrics, and broken links.</p>
    </div>
</div>

<div class="card">
    <div style="display: flex; gap: 24px; margin-bottom: 24px;">
        <div>
            <div class="card-title">Discovered Pages</div>
            <div style="font-size: 1.5rem; font-weight: bold;">{{ $urls->where('is_external', false)->count() }}</div>
        </div>
        <div>
            <div class="card-title">External Links</div>
            <div style="font-size: 1.5rem; font-weight: bold;">{{ $urls->where('is_external', true)->count() }}</div>
        </div>
        <div>
            <div class="card-title">Broken Links</div>
            <div style="font-size: 1.5rem; font-weight: bold; color: var(--danger);">
                {{ $lastRun ? \ThePrimeStudio\Audit\Models\AuditLink::whereHas('url', fn($q) => $q->where('audit_run_id', $lastRun->id))->where('is_broken', true)->count() : 0 }}
            </div>
        </div>
    </div>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>URL</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Response Time</th>
                    <th>Size</th>
                    <th>Content Type</th>
                </tr>
            </thead>
            <tbody>
                @forelse($urls as $url)
                    <tr>
                        <td style="max-width: 400px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                            <a href="{{ $url->url }}" target="_blank" style="color: var(--primary); text-decoration: none;">{{ $url->url }}</a>
                        </td>
                        <td>
                            <span class="badge badge-{{ $url->is_external ? 'info' : 'medium' }}">
                                {{ $url->is_external ? 'External' : 'Internal' }}
                            </span>
                        </td>
                        <td>
                            @if($url->httpResult)
                                <span class="badge badge-{{ $url->httpResult->status_code >= 400 ? 'critical' : 'low' }}">
                                    {{ $url->httpResult->status_code ?: 'N/A' }}
                                </span>
                            @else
                                <span class="badge badge-info">Pending</span>
                            @endif
                        </td>
                        <td>{{ $url->httpResult?->response_time_ms ? $url->httpResult->response_time_ms . ' ms' : 'N/A' }}</td>
                        <td>{{ $url->httpResult?->response_size_bytes ? number_format($url->httpResult->response_size_bytes / 1024, 2) . ' KB' : 'N/A' }}</td>
                        <td>{{ $url->httpResult?->content_type ?: 'N/A' }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--text-secondary);">No URL crawl data exists yet.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
