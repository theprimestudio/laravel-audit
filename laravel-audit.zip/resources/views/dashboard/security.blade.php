@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>Security Diagnostics</h1>
        <p>Analyze HTTP security headers, SSL status, and sensitive configurations.</p>
    </div>
</div>

<div class="card">
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>URL</th>
                    <th>HTTPS</th>
                    <th>HSTS</th>
                    <th>CSP</th>
                    <th>X-Frame-Options</th>
                    <th>Cookie Checks</th>
                </tr>
            </thead>
            <tbody>
                @forelse($securityResults as $url)
                    @if($url->securityResult)
                        <tr>
                            <td><a href="{{ $url->url }}" target="_blank" style="color: var(--primary); text-decoration: none;">{{ $url->path ?: '/' }}</a></td>
                            <td>
                                <span class="badge badge-{{ $url->securityResult->is_https ? 'low' : 'critical' }}">
                                    {{ $url->securityResult->is_https ? 'Secure' : 'Insecure' }}
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-{{ $url->securityResult->hsts_enabled ? 'low' : 'critical' }}">
                                    {{ $url->securityResult->hsts_enabled ? 'Enabled' : 'Disabled' }}
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-{{ $url->securityResult->csp_header ? 'low' : 'high' }}">
                                    {{ $url->securityResult->csp_header ? 'Configured' : 'Missing' }}
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-{{ $url->securityResult->x_frame_options ? 'low' : 'high' }}">
                                    {{ $url->securityResult->x_frame_options ?: 'Missing' }}
                                </span>
                            </td>
                            <td>
                                <span class="badge badge-low">Secure</span>
                                <span class="badge badge-low">HttpOnly</span>
                            </td>
                        </tr>
                    @endif
                @empty
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--text-secondary);">No security audit results found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
