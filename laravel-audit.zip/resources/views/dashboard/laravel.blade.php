@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>Laravel Application Diagnostics</h1>
        <p>Inspect active routes, middleware security layers, database query profiles, and logged exceptions.</p>
    </div>
</div>

<div class="grid">
    <div class="card" style="grid-column: span 2;">
        <h3>Registered Routes & Security Middlewares</h3>
        <div class="table-container" style="max-height: 400px; overflow-y: auto;">
            <table>
                <thead>
                    <tr>
                        <th>URI</th>
                        <th>Method</th>
                        <th>Controller / Action</th>
                        <th>Middleware</th>
                        <th>Auth</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($routes as $route)
                        <tr>
                            <td style="font-weight: 600;">{{ $route->uri }}</td>
                            <td>
                                @foreach($route->methods as $m)
                                    <span class="badge badge-info" style="font-size: 0.65rem;">{{ $m }}</span>
                                @endforeach
                            </td>
                            <td style="color: var(--text-secondary); font-size: 0.85rem;">{{ $route->controller }}</td>
                            <td style="font-size: 0.75rem;">{{ implode(', ', $route->middleware) }}</td>
                            <td>
                                <span class="badge badge-{{ $route->is_protected ? 'low' : 'warning' }}">
                                    {{ $route->is_protected ? 'Protected' : 'Public' }}
                                </span>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" style="text-align: center; color: var(--text-secondary);">No route diagnostics loaded.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <h3>Recent Database Queries</h3>
        <div class="table-container" style="max-height: 400px; overflow-y: auto;">
            <table>
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Query</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($queries as $query)
                        <tr>
                            <td>
                                <span style="font-weight: 600; color: {{ $query->time_ms > 100 ? 'var(--danger)' : 'var(--success)' }}">
                                    {{ $query->time_ms }} ms
                                </span>
                            </td>
                            <td style="font-family: monospace; font-size: 0.75rem; word-break: break-all;">
                                {{ $query->sql }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="2" style="text-align: center; color: var(--text-secondary);">No queries logged.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card" style="margin-top: 24px;">
    <h3>Logged Application Exceptions</h3>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Exception Class</th>
                    <th>Message</th>
                    <th>File & Line</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody>
                @forelse($exceptions as $exception)
                    <tr>
                        <td style="font-weight: bold; color: var(--danger);">{{ $exception->class }}</td>
                        <td>{{ $exception->message }}</td>
                        <td style="font-size: 0.85rem; color: var(--text-secondary);">{{ $exception->file }}:{{ $exception->line }}</td>
                        <td>{{ $exception->occurred_at ? $exception->occurred_at->format('Y-m-d H:i') : 'N/A' }}</td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="4" style="text-align: center; color: var(--text-secondary);">No exceptions recorded in this run.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
