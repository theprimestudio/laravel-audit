@extends('audit::layout')

@section('content')
<div class="header">
    <div class="title">
        <h1>Technical SEO Diagnostics</h1>
        <p>Inspect search engine metadata, headings, schemas, and missing attributes.</p>
    </div>
</div>

<div class="card">
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>URL</th>
                    <th>Title</th>
                    <th>Meta Description</th>
                    <th>Canonical</th>
                    <th>H1 Headings</th>
                    <th>OG / Twitter</th>
                </tr>
            </thead>
            <tbody>
                @forelse($seoResults as $url)
                    @if($url->seoResult)
                        <tr>
                            <td style="max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                                <a href="{{ $url->url }}" target="_blank" style="color: var(--primary); text-decoration: none;">{{ $url->path ?: '/' }}</a>
                            </td>
                            <td>
                                <div style="font-weight: bold; max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="{{ $url->seoResult->title }}">
                                    {!! $url->seoResult->title ? e($url->seoResult->title) : '<i class="fa-solid fa-xmark text-danger" style="color: var(--danger);"></i> Missing' !!}
                                </div>
                                <div style="font-size: 0.75rem; color: var(--text-secondary);">
                                    Length: {{ strlen($url->seoResult->title ?? '') }} chars
                                </div>
                            </td>
                            <td>
                                <div style="max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="{{ $url->seoResult->meta_description }}">
                                    {!! $url->seoResult->meta_description ? e($url->seoResult->meta_description) : '<i class="fa-solid fa-xmark text-danger" style="color: var(--danger);"></i> Missing' !!}
                                </div>
                                <div style="font-size: 0.75rem; color: var(--text-secondary);">
                                    Length: {{ strlen($url->seoResult->meta_description ?? '') }} chars
                                </div>
                            </td>
                            <td>
                                <span style="font-size: 0.85rem;" class="{{ $url->seoResult->canonical_url ? 'text-success' : 'text-danger' }}">
                                    {!! $url->seoResult->canonical_url ? '<i class="fa-solid fa-check text-success" style="color: var(--success);"></i> Valid' : '<i class="fa-solid fa-xmark text-danger" style="color: var(--danger);"></i> Missing' !!}
                                </span>
                            </td>
                            <td>
                                @if($url->seoResult->h1_headings)
                                    <div style="font-size: 0.85rem;">
                                        {{ count($url->seoResult->h1_headings) }} H1s ({{ implode(', ', array_slice($url->seoResult->h1_headings, 0, 2)) }})
                                    </div>
                                @else
                                    <span style="color: var(--danger);"><i class="fa-solid fa-xmark"></i> None</span>
                                @endif
                            </td>
                            <td>
                                <span class="badge badge-{{ $url->seoResult->has_open_graph ? 'low' : 'critical' }}">OG</span>
                                <span class="badge badge-{{ $url->seoResult->has_twitter_card ? 'low' : 'critical' }}">TW</span>
                            </td>
                        </tr>
                    @endif
                @empty
                    <tr>
                        <td colspan="6" style="text-align: center; color: var(--text-secondary);">No SEO audit results found.</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>
@endsection
