<?php

namespace ThePrimeStudio\Audit\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use ThePrimeStudio\Audit\Models\AuditRun;
use ThePrimeStudio\Audit\Services\CrawlerService;
use ThePrimeStudio\Audit\Managers\CheckManager;
use ThePrimeStudio\Audit\Services\ScoringService;

class RunAuditJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public int $timeout = 1800; // 30 minutes max

    public function __construct(protected AuditRun $run) {}

    public function handle(): void
    {
        ini_set('memory_limit', '2G');

        $this->updateProgress(0, 'Initializing audit...');
        $this->run->update(['status' => 'running', 'started_at' => now()]);

        try {
            // Phase 1: Crawling (0% – 40%)
            $this->updateProgress(2, 'Crawling: Starting site discovery...');
            $crawler = new CrawlerService();
            $crawler->crawl($this->run, url('/'));
            $this->updateProgress(40, 'Crawling: Complete — ' . $this->run->fresh()->urls_crawled . ' URLs discovered');

            // Phase 2: SEO & Security Audits (40% – 80%)
            $this->updateProgress(42, 'Audits: Running SEO, Security & Performance checks...');
            $checkManager = app(CheckManager::class);
            $checkManager->execute($this->run);
            $this->updateProgress(80, 'Audits: All checks complete');

            // Phase 3: Route Logging (80% – 90%)
            $this->updateProgress(82, 'Routes: Logging registered application routes...');
            $this->logRegisteredRoutes();
            $this->updateProgress(90, 'Routes: Complete');

            // Phase 4: Scoring (90% – 100%)
            $this->updateProgress(92, 'Scoring: Computing audit scores...');
            $scoring = new ScoringService();
            $scoring->calculate($this->run);

            $this->run->update([
                'status' => 'completed',
                'progress_percent' => 100,
                'progress_message' => 'Audit completed successfully',
                'completed_at' => now(),
            ]);

        } catch (\Exception $e) {
            $this->run->update([
                'status' => 'failed',
                'error_message' => $e->getMessage(),
                'progress_message' => 'Failed: ' . \Illuminate\Support\Str::limit($e->getMessage(), 200),
                'completed_at' => now(),
            ]);
        }
    }

    protected function updateProgress(int $percent, string $message): void
    {
        $this->run->update([
            'progress_percent' => $percent,
            'progress_message' => $message,
        ]);
    }

    protected function logRegisteredRoutes(): void
    {
        $routes = \Illuminate\Support\Facades\Route::getRoutes();
        foreach ($routes as $route) {
            $uri = $route->uri();
            if (\Illuminate\Support\Str::startsWith($uri, ['admin/audit', '_ignition', 'telescope', 'horizon', 'pulse', 'sanctum'])) {
                continue;
            }
            $this->run->routes()->create([
                'uri' => $uri,
                'methods' => $route->methods(),
                'name' => $route->getName(),
                'controller' => $route->getActionName(),
                'middleware' => (array) $route->middleware(),
                'is_protected' => collect($route->middleware())->contains(fn($m) => \Illuminate\Support\Str::contains($m, ['auth', 'signed', 'verified'])),
            ]);
        }
    }
}

