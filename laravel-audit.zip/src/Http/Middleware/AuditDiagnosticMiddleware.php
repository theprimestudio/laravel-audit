<?php

namespace ThePrimeStudio\Audit\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Event;
use Illuminate\Log\Events\MessageLogged;
use ThePrimeStudio\Audit\Models\AuditUrl;
use ThePrimeStudio\Audit\Models\AuditPerformanceResult;
use ThePrimeStudio\Audit\Models\AuditQuery;
use ThePrimeStudio\Audit\Models\AuditException;

class AuditDiagnosticMiddleware
{
    protected static float $startTime;
    protected static int $startMemory;
    protected static ?int $runId = null;

    public function handle(Request $request, Closure $next)
    {
        $hasHeader = $request->hasHeader('X-Audit-Run-Id');
        $runId = $request->header('X-Audit-Run-Id');

        if ($hasHeader) {
            self::$runId = (int) $runId;
            self::$startTime = microtime(true);
            self::$startMemory = memory_get_usage();

            DB::enableQueryLog();

            // Bind a place to capture exceptions
            app()->singleton('audit.exception', function () {
                return null;
            });

            // Listen for logged exceptions
            Event::listen(MessageLogged::class, function (MessageLogged $event) {
                if (isset($event->context['exception']) && $event->context['exception'] instanceof \Throwable) {
                    app()->instance('audit.exception', $event->context['exception']);
                }
            });
        }

        return $next($request);
    }

    public function terminate(Request $request, $response)
    {
        if (! self::$runId) {
            return;
        }

        // Find the audit url record for this path and run
        $auditUrl = AuditUrl::where('audit_run_id', self::$runId)
            ->where(function ($q) use ($request) {
                $q->where('url', $request->fullUrl())
                  ->orWhere('path', $request->getPathInfo());
            })
            ->first();

        if (! $auditUrl) {
            return;
        }

        $queries = DB::getQueryLog();
        $queryCount = count($queries);
        $queryTimeMs = (int) array_sum(array_column($queries, 'time'));

        // Save queries
        foreach ($queries as $q) {
            AuditQuery::create([
                'audit_run_id' => self::$runId,
                'sql' => $q['query'],
                'bindings' => $q['bindings'],
                'time_ms' => (int) $q['time'],
                'connection' => DB::getDefaultConnection(),
            ]);
        }

        // Save performance result
        $memoryUsageBytes = max(0, memory_get_peak_usage() - self::$startMemory);
        AuditPerformanceResult::create([
            'audit_url_id' => $auditUrl->id,
            'memory_usage_bytes' => $memoryUsageBytes,
            'query_count' => $queryCount,
            'query_time_ms' => $queryTimeMs,
        ]);

        // Save exception if any was logged
        if (app()->bound('audit.exception')) {
            $exception = app('audit.exception');
            if ($exception instanceof \Throwable) {
                AuditException::create([
                    'audit_run_id' => self::$runId,
                    'class' => get_class($exception),
                    'message' => $exception->getMessage(),
                    'trace' => $exception->getTrace(),
                    'file' => $exception->getFile(),
                    'line' => $exception->getLine(),
                    'occurred_at' => now(),
                ]);
            }
        }
    }
}
