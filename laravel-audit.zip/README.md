# Laravel Audit

A standalone, self-hosted website and application audit platform for Laravel applications, developed by **The Prime Studio**. It analyzes your application's SEO integrity, security headers, Laravel configuration safety, database performance parameters, and API statuses dynamically.

## Installation

Add the package via Composer:

```bash
composer require theprimestudio/laravel-audit
```

Publish configuration and database migrations:

```bash
php artisan vendor:publish --provider="ThePrimeStudio\Audit\AuditServiceProvider"
```

Run database migrations:

```bash
php artisan migrate
```

## Running Audits

You can trigger audit diagnostics directly from the platform interface or via console commands:

```bash
# Run a new audit diagnostic session
php artisan audit:run

# Check the status of the last run
php artisan audit:status

# Export console report of issues
php artisan audit:report
```

## License

The MIT License (MIT). Please see [LICENSE](LICENSE) for more details.
